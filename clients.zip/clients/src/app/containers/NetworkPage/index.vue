<template>
  <div>
    <div class="container-fluid">
      <div class="ft-page network">
        <h4 class="header">My network</h4>

        <b-row>

           <b-col lg="6" md="6" id="select_box">

              <select class="network-widget-sort">
                <option disabled selected value>Sort by</option>
                <option value="name">Name</option>
                <option value="club">Club</option>
              </select>

             </b-col>

              <b-col lg="6" md="6" id="select_box">

              <input type="text" class="network-widget-search" placeholder="Type a name" />
             </b-col>





        <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

        </b-col>

        <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle_right">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

         </b-col>


         <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

        </b-col>

        <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle_right">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

         </b-col>

         <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

        </b-col>

        <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle_right">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

         </b-col>

         <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

        </b-col>

        <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle_right">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

         </b-col>

         <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

        </b-col>

        <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle_right">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

         </b-col>

         <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

        </b-col>

        <b-col lg="6" md="6" id="leonel_sec">

          <div class="leonel_tittle_right">
            <div class="glob_sec"> <img src="http://demourls.xyz/first-touch/lionel-img.png"> </div>
            <div class="player_sec">
              <h3>LEONEL MESSI</h3>
              <p>Football player</p>
              <p>Barcelona FC, Spain</p>
            </div>
            <img src="http://demourls.xyz/first-touch/dote.png">
            <div class="clear"></div>
          </div>

         </b-col>



      </b-row>

        <div class="network-container">
          <div v-if="loading">
            <h4 class="text-center">Loading...</h4>
          </div>
          <network-item v-for="item in items"
            :info="item"
            :unfollow="unfollow.bind(this, { token: token.value, id: item.id })"
            :key="item.id"
            />
        </div>
      </div>
    </div>

  <sidebar />

  </div>
</template>

<style lang="scss" scoped>
@import '~stylesheets/variables';
@import '~stylesheets/common_style';

.network {
  .network-widget {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    .network-widget-sort,
    .network-widget-search {
      flex: 0 0 48%;
      border: 1px solid $main-text-color;
      background-color: $navbar-background-color;
      color: $main-text-color;
      padding: 2px 7px;
    }
    .network-widget-search {
      border-radius: 4px;
    }
  }
  .network-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }
}


.leonel_sec {
    padding: 32px 0 0 0;
}

.leonel_tittle {
    width: 330px;
    background-color: #fff;
    display: inline-block;
    padding: 15px;
    border-radius: 5px;
}


.player_sec {
    width: 180px;
    display: inline-block;
}

.leonel_tittle_right {
    width: 330px;
    background-color: #fff;
    display: inline-block;
    padding: 15px;
    float: right;
    border-radius: 5px;
}


.glob_sec {
    width: 72px;
    display: inline-block;
    padding-right: 12px;
    position: relative;
    top: 5px;
    vertical-align: top;
}

.player_sec {
    width: 180px;
    display: inline-block;
}
.player_sec h3 {
    font-size: 18px;
    color: #a5ce4b;
    font-family: 'ubuntu_condensedregular';
    letter-spacing: 2px;
}

.player_sec p {
    font-size: 16px;
    color: #606060;
    font-family: ubuntulight;
    letter-spacing: 1px;
    margin: 0;
}




</style>

<script>
import { mapGetters, mapActions } from 'vuex';
import { ASYNC_LOADING, ASYNC_SUCCESS } from 'app/constants/AsyncStatus';

import NotificationSidebar from 'app/components/NotificationSidebar.vue';
import NetworkItem from './components/NetworkItem.vue';

export default {
  name: 'Network',
  components: {
    sidebar: NotificationSidebar,
    'network-item': NetworkItem,
  },
  computed: {
    ...mapGetters(['token', 'network']),
    loading() {
      return this.network.status === ASYNC_LOADING;
    },
    items() {
      return this.network.value || [];
    },
  },
  methods: {
    ...mapActions(['getNetwork', 'unfollow']),
  },
  mounted() {
    this.getNetwork({ token: this.token.value });
  },
};
</script>
