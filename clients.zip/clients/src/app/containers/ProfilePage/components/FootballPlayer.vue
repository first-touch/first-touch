<template>
  <timeline-item>

    <b-row>

        <b-col lg="12" md="12" sm="6" id="head-tag">
           <h3>YOUR PROFILE </h3>
          <h4>Football player</h4>
        </b-col>

    </b-row>

  <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec" >
       <div class="history_iocn">
         <img src="http://demourls.xyz/first-touch/fc_icon.png">
       </div>

      <div class="history_cont">
        <h3>REAL MADRID FC</h3>
        <span>Madrid, Spain</span>
      </div>

    </b-col>


    <b-col lg="6" md="6" sm="6" id="real-sec" >
      <div class="history_date">
       <span>July 2009 - present</span>
       <span>Apss 236 | Gls 260</span>
      </div>

    </b-col>

  </b-row>


  <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec" >
       <div class="history_iocn">
         <img src="http://demourls.xyz/first-touch/clube_icon.png">
       </div>

      <div class="history_cont">
        <h3>MANCHESTER UNITED</h3>
        <span>Manchester, England</span>
      </div>




    </b-col>

    <b-col lg="6" md="6" sm="6" id="real-sec">
      <div class="history_date">
       <span>July 2009 - present</span>
       <span>Apss 236 | Gls 260</span>
      </div>

    </b-col>

  </b-row>

  <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec">
        <div class="history_iocn">
        <img src="http://demourls.xyz/first-touch/united_icon.png">
        </div>

      <div class="history_cont">
       <h3>SPORTING CLUBE DE PORTUGAL</h3>
       <span>Lisbon, Portugal</span> </div>
      </div>

    </b-col>

    <b-col lg="6" md="6" sm="6" id="real-sec" >
      <div class="history_date">
       <span> 2002 - July 2003</span>
       <span>Apps 196 | Gls 84</span>
      </div>

    </b-col>

  </b-row>

  <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec" >
       <div class="history_iocn"> <img src="http://demourls.xyz/first-touch/united_icon.png"> </div>
      <div class="history_cont">
                      <h3>SPORTING CLUBE DE PORTUGAL B</h3>
                      <span>Lisbon, Portugal</span> </div>

    </b-col>

    <b-col lg="6" md="6" sm="6" id="real-sec" >
 <div class="history_date"> <span>July 2002 - July 2003</span> <span>Apps 2 | Gls 0</span> </div>

    </b-col>

  </b-row>

  <b-row>

        <b-col lg="12" md="12" sm="6" id="head-tag">
           <h3>YOUR PROFILE </h3>
         </b-col>

    </b-row>




  <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec">
  <div class="history_iocn"> <img src="http://demourls.xyz/first-touch/team_icon.png"> </div>
        <div class="history_cont">
                      <h3>PORTUGAL</h3>
                     </div>

    </b-col>

    <b-col lg="6" md="6" sm="6" id="real-sec">
 <div class="history_date">  <span>2003 - present</span> <span>Apss 125 | Gls 56</span> </div>

    </b-col>

  </b-row>


   <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec">
  <div class="history_iocn"> <img src="http://demourls.xyz/first-touch/team_icon.png"> </div>
        <div class="history_cont">
                      <h3>PORTUGAL</h3>
                     </div>

    </b-col>

    <b-col lg="6" md="6" sm="6" id="real-sec">
 <div class="history_date">  <span>2003 - present</span> <span>Apss 125 | Gls 56</span> </div>

    </b-col>

  </b-row>

   <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec">
  <div class="history_iocn"> <img src="http://demourls.xyz/first-touch/team_icon.png"> </div>
        <div class="history_cont">
                      <h3>PORTUGAL</h3>
                     </div>

    </b-col>

    <b-col lg="6" md="6" sm="6" id="real-sec">
 <div class="history_date">  <span>2003 - present</span> <span>Apss 125 | Gls 56</span> </div>

    </b-col>

  </b-row>

   <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec">
  <div class="history_iocn"> <img src="http://demourls.xyz/first-touch/team_icon.png"> </div>
        <div class="history_cont">
                      <h3>PORTUGAL</h3>
                     </div>

    </b-col>

    <b-col lg="6" md="6" sm="6" id="real-sec">
 <div class="history_date">  <span>2003 - present</span> <span>Apss 125 | Gls 56</span> </div>

    </b-col>

  </b-row>

   <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec">
  <div class="history_iocn"> <img src="http://demourls.xyz/first-touch/team_icon.png"> </div>
        <div class="history_cont">
                      <h3>PORTUGAL</h3>
                     </div>

    </b-col>

    <b-col lg="6" md="6" sm="6" id="real-sec">
 <div class="history_date">  <span>2003 - present</span> <span>Apss 125 | Gls 56</span> </div>

    </b-col>

  </b-row>

   <b-row>
        <b-col lg="6" md="6" sm="6" id="real-sec">
  <div class="history_iocn"> <img src="http://demourls.xyz/first-touch/team_icon.png"> </div>
        <div class="history_cont">
                      <h3>PORTUGAL</h3>
                     </div>

    </b-col>

    <b-col lg="6" md="6" sm="6" id="real-sec">
 <div class="history_date">  <span>2003 - present</span> <span>Apss 125 | Gls 56</span> </div>

    </b-col>

  </b-row>


  <b-row>
        <b-col lg="12" md="12" sm="6">

  <div class="mat_button">
                    <div class="button_div"> <a href="#">EDIT PROFILE</a> </div>
                    <div class="button_div"> <a href="#">EDIT PROFILE</a> </div>
                  </div>

    </b-col>



  </b-row>










  </timeline-item>
</template>

<style>

.profile_cont {
    width: 92%;
    margin: auto;
    padding-top: 20px;
    border-bottom: 1px solid #d5d5d5;
}
#head-tag { margin-top:20px;}

#head-tag h3 {
    color: #797979;
    font-size: 18px;
    font-family: ubuntulight;
    letter-spacing: 4px;
}



#real-sec {
    margin-top: 19px;
    border-bottom: 1px solid#929292;
}



.history_div {
    display: inline-block;
}

#head-tag h4 {
    color: #797979;
    font-size: 16px;
    font-family: ubuntulight;
    letter-spacing: 0px;
    text-transform: uppercase;
    font-weight: normal;
    margin-top: 30px;
}

.history_box {
    float: left;
    width: 100%;
    padding: 14px 0;
    border-bottom: 1px solid #d5d5d5;
}

.history_iocn {
    float: left;
    width: 60px;
}
.history_cont {
    float: left;
    width: 70%;
}

.history_cont h3 {
    color: #a8a8a8;
    font-size: 16px;
    font-family: ubuntulight;
    letter-spacing: 1px;
    margin: 7px 0 3px 0;
}

.history_cont span {
    color: #797979;
    font-size: 16px;
    font-family: ubuntulight;
    margin-top: 10px;
    letter-spacing: 1px;
}

.history_date {
    float: right;
    width: 165px;
    margin-top: 10px;
}

.history_date span {
    color: #797979;
    font-size: 16px;
    font-family: ubuntulight;
    margin-top: 10px;
    letter-spacing: 1px;
}
.history_box_div {
    color: #a8a8a8;
    float: left;
    width: 100%;
    padding: 14px 0;
    border-bottom: 1px solid #d5d5d5;
}
.team_dis {
    display: none;
    float: left;
    width: 100%;
}

.history_cont_div {
    float: left;
    width: 270px;
}

.history_heading {
    font-size: 16px;
    font-family: ubuntulight;
    letter-spacing: 1px;
    margin: 24px 0 3px 0;
    font-weight: bold;
}
.history_date_div {
    float: right;
    width: 165px;
    margin-top: 10px;
}
.history_date_div span {
    font-size: 16px;
    font-family: ubuntulight;
    margin-top: 10px;
    letter-spacing: 1px;
}

.mat_button {
    float: right;
}

.button_div {
    float: left;
    margin: 35px 5px;
}

.button_div a {
    border: 1px solid #a8a8a8;
    text-align: center;
    padding: 5px 12px;
    border-radius: 3px;
    font-size: 12px;
    color: #a8a8a8;
    text-decoration: none;
    letter-spacing: 3px;
    font-family: 'ubuntulight';
}

.button_div {
    float: left;
    margin: 35px 5px;
}

.button_div a {
    border: 1px solid #a8a8a8;
    text-align: center;
    padding: 5px 12px;
    border-radius: 3px;
    font-size: 12px;
    color: #a8a8a8;
    text-decoration: none;
    letter-spacing: 3px;
    font-family: 'ubuntulight';
}


</style>


<script>
import TimelineItem from 'app/components/TimelineItem';

export default {
  name: 'Footballplayer',
  components: {
    'timeline-item': TimelineItem,
  },
  props: ['footballplayer'],
};
</script>
