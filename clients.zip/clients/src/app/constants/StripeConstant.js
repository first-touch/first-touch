export const StripePublicKey = 'pk_test_VpC94D3goj5uGD6KsbDDswN3';
