export const ASYNC_NONE = 'ASYNC_NONE';
export const ASYNC_LOADING = 'ASYNC_LOADING';
export const ASYNC_SUCCESS = 'ASYNC_SUCCESS';
export const ASYNC_FAIL = 'ASYNC_FAIL';
